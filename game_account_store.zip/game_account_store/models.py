from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import json

db = SQLAlchemy()

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    balance = db.Column(db.Float, default=0.0)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    orders = db.relationship('Order', backref='user', lazy=True)
    tickets = db.relationship('SupportTicket', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'


class Category(db.Model):
    __tablename__ = 'categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    image = db.Column(db.String(255), nullable=True)  # Kategori resmi için
    
    # Relationships
    accounts = db.relationship('GameAccount', backref='category', lazy=True)
    
    def __repr__(self):
        return f'<Category {self.name}>'


class GameAccount(db.Model):
    __tablename__ = 'game_accounts'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, default=1)
    credentials = db.Column(db.Text, nullable=False)  # Stored as JSON: {"username": "...", "password": "..."}
    additional_stock = db.Column(db.Text, nullable=True)  # Stored as JSON array of credentials
    is_visible = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign Keys
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id'), nullable=False)
    
    # Relationships
    images = db.relationship('GameAccountImage', backref='game_account', lazy=True, cascade="all, delete-orphan")
    order_items = db.relationship('OrderItem', backref='game_account', lazy=True)
    
    def get_credentials(self):
        return json.loads(self.credentials)
    
    def set_credentials(self, username, password):
        self.credentials = json.dumps({"username": username, "password": password})
    
    def __repr__(self):
        return f'<GameAccount {self.title}>'


class GameAccountImage(db.Model):
    __tablename__ = 'game_account_images'
    
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    is_primary = db.Column(db.Boolean, default=False)
    
    # Foreign Keys
    game_account_id = db.Column(db.Integer, db.ForeignKey('game_accounts.id'), nullable=False)
    
    def __repr__(self):
        return f'<GameAccountImage {self.filename}>'


class Order(db.Model):
    __tablename__ = 'orders'
    
    id = db.Column(db.Integer, primary_key=True)
    order_number = db.Column(db.String(20), nullable=False, unique=True)
    total_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='completed')  # completed, pending, cancelled
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign Keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Relationships
    items = db.relationship('OrderItem', backref='order', lazy=True, cascade="all, delete-orphan")
    tickets = db.relationship('SupportTicket', foreign_keys='SupportTicket.related_order_id', lazy=True)
    
    def __repr__(self):
        return f'<Order {self.order_number}>'


class OrderItem(db.Model):
    __tablename__ = 'order_items'
    
    id = db.Column(db.Integer, primary_key=True)
    price = db.Column(db.Float, nullable=False)
    
    # Foreign Keys
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=False)
    game_account_id = db.Column(db.Integer, db.ForeignKey('game_accounts.id'), nullable=False)
    
    def __repr__(self):
        return f'<OrderItem {self.id}>'


class SupportTicket(db.Model):
    __tablename__ = 'support_tickets'
    
    id = db.Column(db.Integer, primary_key=True)
    ticket_number = db.Column(db.String(20), nullable=False, unique=True)
    subject = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='open')  # open, in_progress, closed, resolved
    priority = db.Column(db.String(20), default='normal')  # low, normal, high, urgent
    category = db.Column(db.String(50), default='general')  # general, technical, billing, account
    is_locked = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    closed_at = db.Column(db.DateTime, nullable=True)
    
    # Foreign Keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    related_order_id = db.Column(db.Integer, db.ForeignKey('orders.id'), nullable=True)
    
    # Relationships
    replies = db.relationship('TicketReply', backref='ticket', lazy=True, cascade="all, delete-orphan")
    related_order = db.relationship('Order', lazy=True, overlaps="tickets")
    
    def __repr__(self):
        return f'<SupportTicket #{self.ticket_number}: {self.subject}>'


class TicketReply(db.Model):
    __tablename__ = 'ticket_replies'
    
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    is_from_admin = db.Column(db.Boolean, default=False)
    is_internal_note = db.Column(db.Boolean, default=False)  # Sadece admin görebilir
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign Keys
    ticket_id = db.Column(db.Integer, db.ForeignKey('support_tickets.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Relationships
    user = db.relationship('User', backref='ticket_replies', lazy=True)
    
    def __repr__(self):
        return f'<TicketReply {self.id} for Ticket {self.ticket_id}>'


class Settings(db.Model):
    __tablename__ = 'settings'
    
    id = db.Column(db.Integer, primary_key=True)
    # Ödeme bilgileri
    bank_name = db.Column(db.String(100), nullable=True)
    bank_account_name = db.Column(db.String(100), nullable=True)
    bank_iban = db.Column(db.String(50), nullable=True)
    papara_number = db.Column(db.String(20), nullable=True)
    papara_account_name = db.Column(db.String(100), nullable=True)
    payment_instructions = db.Column(db.Text, nullable=True)
    # Site ayarları
    site_name = db.Column(db.String(100), nullable=True)
    site_description = db.Column(db.Text, nullable=True)
    contact_email = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<Settings {self.id}>'


class Payment(db.Model):
    __tablename__ = 'payments'
    
    id = db.Column(db.Integer, primary_key=True)
    payment_id = db.Column(db.String(100), unique=True, nullable=False)
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, completed, failed
    payment_method = db.Column(db.String(50), default='manual_transfer')  # manual_transfer, papara
    payment_details = db.Column(db.Text, nullable=True)  # Kullanıcının girdiği ödeme detayları (dekont no, açıklama vb.)
    reference_number = db.Column(db.String(100), nullable=True)  # Kullanıcının girdiği referans numarası
    proof_image = db.Column(db.String(255), nullable=True)  # Ödeme kanıtı (dekont fotoğrafı)
    admin_notes = db.Column(db.Text, nullable=True)  # Admin tarafından eklenen notlar
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign Keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Relationships
    user = db.relationship('User', backref='payments', lazy=True)
    
    def __repr__(self):
        return f'<Payment {self.payment_id}>'
