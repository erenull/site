import os
import json
import random
import hashlib
import hmac
import base64
import uuid
import requests
from datetime import datetime
from functools import wraps

from flask import Flask, render_template, redirect, url_for, flash, request, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash

from models import db, User, Category, GameAccount, GameAccountImage, Order, OrderItem, SupportTicket, TicketReply, Payment, Settings

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'default-secret-key-for-development')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///game_store.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static', 'img', 'accounts')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize extensions
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Lütfen bu sayfayı görüntülemek için giriş yapın.'

# Shopier configuration
SHOPIER_API_KEY = os.environ.get('SHOPIER_API_KEY', 'your-shopier-api-key')
SHOPIER_API_SECRET = os.environ.get('SHOPIER_API_SECRET', 'your-shopier-api-secret')
SHOPIER_CALLBACK_URL = os.environ.get('SHOPIER_CALLBACK_URL', 'http://localhost:5000/payment/callback')

# User loader for Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Admin required decorator
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Bu sayfaya erişim izniniz yok.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

# Routes
@app.route('/')
def index():
    categories = Category.query.all()
    # Eager loading ile images ilişkisini de yükleyelim
    featured_accounts = GameAccount.query.filter_by(is_visible=True).order_by(GameAccount.created_at.desc()).options(db.joinedload(GameAccount.images)).limit(6).all()
    return render_template('index.html', categories=categories, featured_accounts=featured_accounts)

@app.route('/category/<int:category_id>')
def category_view(category_id):
    category = Category.query.get_or_404(category_id)
    # Eager loading ile images ilişkisini de yükleyelim
    accounts = GameAccount.query.filter_by(category_id=category_id, is_visible=True).options(db.joinedload(GameAccount.images)).all()
    return render_template('category.html', category=category, accounts=accounts)

@app.route('/account/<int:account_id>')
def account_detail(account_id):
    account = GameAccount.query.get_or_404(account_id)
    if not account.is_visible and (not current_user.is_authenticated or not current_user.is_admin):
        flash('Bu hesap şu anda görüntülenemiyor.', 'warning')
        return redirect(url_for('index'))
    return render_template('account_detail.html', account=account)

@app.route('/search')
def search():
    query = request.args.get('q', '')
    if not query:
        return redirect(url_for('index'))
    
    accounts = GameAccount.query.filter(
        GameAccount.is_visible == True,
        GameAccount.title.ilike(f'%{query}%')
    ).all()
    
    return render_template('search_results.html', accounts=accounts, query=query)

# Authentication routes
@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Validation
        if not email or not username or not password:
            flash('Tüm alanları doldurunuz.', 'danger')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('Şifreler eşleşmiyor.', 'danger')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Bu e-posta adresi zaten kullanılıyor.', 'danger')
            return render_template('register.html')
        
        if User.query.filter_by(username=username).first():
            flash('Bu kullanıcı adı zaten kullanılıyor.', 'danger')
            return render_template('register.html')
        
        # Create new user
        new_user = User(email=email, username=username)
        new_user.set_password(password)
        
        db.session.add(new_user)
        db.session.commit()
        
        flash('Kayıt başarılı! Şimdi giriş yapabilirsiniz.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            flash('Giriş başarılı!', 'success')
            return redirect(next_page or url_for('index'))
        else:
            flash('Giriş başarısız. Kullanıcı adı veya şifre hatalı.', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Başarıyla çıkış yaptınız.', 'success')
    return redirect(url_for('index'))

# User panel routes
@app.route('/user/dashboard')
@login_required
def user_dashboard():
    user_orders = Order.query.filter_by(user_id=current_user.id).order_by(Order.created_at.desc()).all()
    # Açık destek taleplerini al
    tickets = SupportTicket.query.filter_by(user_id=current_user.id).order_by(SupportTicket.updated_at.desc()).all()
    open_tickets = SupportTicket.query.filter(SupportTicket.user_id == current_user.id, 
                                           SupportTicket.status.in_(['open', 'in_progress'])).count()
    return render_template('user/dashboard.html', orders=user_orders, tickets=tickets, open_tickets=open_tickets)

# Eski mesaj sisteminden yeni destek ticket sistemine yönlendirme
@app.route('/user/messages')
@login_required
def user_messages_redirect():
    return redirect(url_for('user_tickets'))

@app.route('/user/message/<int:message_id>')
@login_required
def view_message_redirect(message_id):
    # Mesaj ID'sini ticket ID'sine dönüştür
    # Burada aynı ID'yi kullanıyoruz, gerçek bir sistemde daha karmaşık bir yönlendirme mantığı olabilir
    return redirect(url_for('view_ticket', ticket_id=message_id))

@app.route('/user/create-ticket', methods=['GET', 'POST'])
@login_required
def create_ticket():
    related_order_id = request.args.get('order_id')
    related_order = None
    
    if related_order_id:
        related_order = Order.query.filter_by(id=related_order_id, user_id=current_user.id).first()
    
    if request.method == 'POST':
        subject = request.form.get('subject')
        content = request.form.get('content')
        category = request.form.get('category', 'general')
        priority = request.form.get('priority', 'normal')
        related_order_id = request.form.get('related_order_id')
        
        if not subject or not content:
            flash('Lütfen tüm alanları doldurun.', 'danger')
            return render_template('user/create_ticket.html', related_order=related_order)
        
        # Ticket numarası oluştur
        ticket_number = f"TKT-{uuid.uuid4().hex[:8].upper()}"
        
        new_ticket = SupportTicket(
            ticket_number=ticket_number,
            subject=subject,
            content=content,
            user_id=current_user.id,
            category=category,
            priority=priority,
            related_order_id=related_order_id if related_order_id else None
        )
        
        db.session.add(new_ticket)
        db.session.commit()
        
        flash('Destek talebiniz başarıyla oluşturuldu.', 'success')
        return redirect(url_for('user_tickets'))
    
    return render_template('user/create_ticket.html', related_order=related_order)

@app.route('/user/tickets')
@login_required
def user_tickets():
    tickets = SupportTicket.query.filter_by(user_id=current_user.id).order_by(SupportTicket.updated_at.desc()).all()
    return render_template('user/tickets.html', tickets=tickets)

@app.route('/user/ticket/<int:ticket_id>', methods=['GET', 'POST'])
@login_required
def view_ticket(ticket_id):
    ticket = SupportTicket.query.filter_by(id=ticket_id, user_id=current_user.id).first_or_404()
    
    if request.method == 'POST' and not ticket.is_locked and ticket.status != 'closed':
        content = request.form.get('content')
        
        if not content:
            flash('Lütfen bir mesaj girin.', 'danger')
            return redirect(url_for('view_ticket', ticket_id=ticket.id))
        
        reply = TicketReply(
            content=content,
            ticket_id=ticket.id,
            user_id=current_user.id,
            is_from_admin=False
        )
        
        # Ticket'ı güncelle
        ticket.status = 'open'  # Kullanıcı yanıt verdiğinde durumu açık olarak işaretle
        ticket.updated_at = datetime.utcnow()
        
        db.session.add(reply)
        db.session.commit()
        
        flash('Yanıtınız gönderildi.', 'success')
        return redirect(url_for('view_ticket', ticket_id=ticket.id))
    
    return render_template('user/view_ticket.html', ticket=ticket, user=current_user)

@app.route('/user/orders')
@login_required
def user_orders():
    orders = Order.query.filter_by(user_id=current_user.id).order_by(Order.created_at.desc()).all()
    return render_template('user/orders.html', orders=orders)

@app.route('/user/order/<int:order_id>')
@login_required
def view_order(order_id):
    order = Order.query.filter_by(id=order_id, user_id=current_user.id).first_or_404()
    return render_template('user/view_order.html', order=order)

# Purchase process
@app.route('/buy/<int:account_id>', methods=['POST'])
@login_required
def buy_account(account_id):
    account = GameAccount.query.get_or_404(account_id)
    
    if not account.is_visible:
        flash('Bu hesap satışta değil.', 'danger')
        return redirect(url_for('index'))
    
    if account.stock <= 0:
        flash('Bu hesap stokta kalmadı.', 'danger')
        return redirect(url_for('account_detail', account_id=account_id))
    
    if current_user.balance < account.price:
        flash('Yetersiz bakiye. Lütfen bakiye yükleyin.', 'danger')
        return redirect(url_for('add_balance'))
    
    # Kullanıcı bilgilerini al
    credentials = account.get_credentials()
    
    # Sipariş oluştur
    order_number = f"ORD-{uuid.uuid4().hex[:8].upper()}"
    new_order = Order(
        order_number=order_number,
        total_amount=account.price,
        user_id=current_user.id,
        status='completed'
    )
    
    db.session.add(new_order)
    db.session.flush()  # Sipariş ID'sini almak için
    
    # Sipariş öğesi oluştur
    order_item = OrderItem(
        order_id=new_order.id,
        game_account_id=account.id,
        price=account.price
    )
    
    db.session.add(order_item)
    
    # Kullanıcı bakiyesini güncelle
    current_user.balance -= account.price
    
    # Hesap stoğunu azalt
    account.stock -= 1
    
    # Eğer additional_stock varsa ve stok sıfırlandıysa, additional_stock'tan bir hesap al
    if account.stock == 0 and account.additional_stock:
        try:
            additional_accounts = json.loads(account.additional_stock)
            if additional_accounts:
                # İlk ek hesabı ana hesap yap
                first_additional = additional_accounts.pop(0)
                account.set_credentials(first_additional['username'], first_additional['password'])
                
                # Stoku güncelle
                account.stock = 1
                
                # Kalan ek hesapları güncelle
                if additional_accounts:
                    account.additional_stock = json.dumps(additional_accounts)
                else:
                    account.additional_stock = None
        except Exception as e:
            print(f"Ek stok güncelleme hatası: {e}")
    
    db.session.commit()
    
    # Satın alınan hesap bilgileriyle kullanıcıya otomatik destek talebi oluştur
    ticket_content = f"""
    Hesap bilgileriniz aşağıdadır:
    
    Hesap: {account.title}
    Kullanıcı Adı: {credentials['username']}
    Şifre: {credentials['password']}
    
    Herhangi bir sorun yaşarsanız bu talep üzerinden bizimle iletişime geçebilirsiniz.
    """
    
    # Yeni destek talebi oluştur
    import random
    import string
    
    # Rastgele ticket numarası oluştur
    ticket_number = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
    
    new_ticket = SupportTicket(
        ticket_number=ticket_number,
        subject=f"Hesap Satın Alımı: {account.title}",
        content=ticket_content,
        user_id=current_user.id,
        category="account",
        priority="normal",
        status="open",
        related_order_id=new_order.id
    )
    
    db.session.add(new_ticket)
    db.session.commit()
    
    # Admin yanıtı ekle
    # Admin kullanıcısını bul
    admin_user = User.query.filter_by(is_admin=True).first()
    
    admin_reply = TicketReply(
        content="Hesap bilgileriniz yukarıda verilmiştir. Herhangi bir sorunuz veya sorununuz olursa bu talep üzerinden yanıt verebilirsiniz.",
        ticket_id=new_ticket.id,
        user_id=admin_user.id,  # Admin kullanıcısının ID'si
        is_from_admin=True,
        is_internal_note=False
    )
    
    db.session.add(admin_reply)
    db.session.commit()
    
    flash('Hesap başarıyla satın alındı. Hesap bilgileriniz destek taleplerinize gönderildi.', 'success')
    return redirect(url_for('view_ticket', ticket_id=new_ticket.id))

# Payment routes
@app.route('/add-balance')
@login_required
def add_balance():
    # Ayarları getir
    settings = Settings.query.first()
    
    # Kullanıcının bekleyen ödemeleri
    pending_payments = Payment.query.filter_by(user_id=current_user.id, status='pending').order_by(Payment.created_at.desc()).all()
    
    return render_template('user/add_balance.html', settings=settings, pending_payments=pending_payments)

@app.route('/create-payment', methods=['POST'])
@login_required
def create_payment():
    amount = float(request.form.get('amount', 0))
    payment_method = request.form.get('payment_method')
    reference_number = request.form.get('reference_number')
    payment_details = request.form.get('payment_details')
    
    if amount < 1:
        flash('Minimum yükleme tutarı 1 ₺ olmalıdır.', 'danger')
        return redirect(url_for('add_balance'))
    
    # Ödeme ID oluştur
    payment_id = str(uuid.uuid4())
    
    # Dekont görseli yüklenmişse işle
    proof_image = None
    if 'proof_image' in request.files:
        file = request.files['proof_image']
        if file and file.filename != '':
            # Güvenli dosya adı oluştur
            filename = secure_filename(file.filename)
            # Dosya uzantısını al
            ext = filename.rsplit('.', 1)[1].lower() if '.' in filename else ''
            
            if ext in ['jpg', 'jpeg', 'png', 'gif']:
                # Benzersiz dosya adı oluştur
                unique_filename = f"{payment_id}_{filename}"
                # Klasör yolu
                upload_folder = os.path.join('static', 'img', 'payments')
                
                # Klasör yoksa oluştur
                if not os.path.exists(upload_folder):
                    os.makedirs(upload_folder)
                
                # Dosyayı kaydet
                file_path = os.path.join(upload_folder, unique_filename)
                file.save(file_path)
                
                # Veritabanına kaydedilecek görsel yolu
                proof_image = os.path.join('img', 'payments', unique_filename)
    
    # Veritabanına ödeme kaydı oluştur
    payment = Payment(
        user_id=current_user.id,
        amount=amount,
        payment_id=payment_id,
        payment_method=payment_method,
        reference_number=reference_number,
        payment_details=payment_details,
        proof_image=proof_image,
        status='pending'
    )
    
    db.session.add(payment)
    db.session.commit()
    
    # Destek talebi oluştur
    ticket_content = f"""
    Bakiye yükleme talebiniz alınmıştır.
    
    Miktar: {amount} ₺
    Ödeme Yöntemi: {'Banka Havalesi' if payment_method == 'manual_transfer' else 'Papara'}
    Referans / Dekont No: {reference_number or 'Belirtilmemiş'}
    
    Ödemeniz kontrol edildikten sonra bakiyeniz hesabınıza tanımlanacaktır.
    """
    
    # Rastgele ticket numarası oluştur
    import random
    import string
    ticket_number = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
    
    new_ticket = SupportTicket(
        ticket_number=ticket_number,
        subject=f"Bakiye Yükleme Talebi: {amount} ₺",
        content=ticket_content,
        user_id=current_user.id,
        category="billing",
        priority="normal",
        status="open"
    )
    
    db.session.add(new_ticket)
    db.session.commit()
    
    flash('Ödeme bildiriminiz başarıyla alındı. Ödemeniz kontrol edildikten sonra bakiyeniz hesabınıza tanımlanacaktır.', 'success')
    return redirect(url_for('view_ticket', ticket_id=new_ticket.id))

# Admin paneli için ödeme yönetimi
@app.route('/admin/payments')
@login_required
@admin_required
def admin_payments():
    # Tüm ödemeleri getir
    payments = Payment.query.order_by(Payment.created_at.desc()).all()
    return render_template('admin/payments.html', payments=payments)

@app.route('/admin/payment/<payment_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_view_payment(payment_id):
    # Ödeme detaylarını getir
    payment = Payment.query.filter_by(payment_id=payment_id).first_or_404()
    
    if request.method == 'POST':
        action = request.form.get('action')
        admin_notes = request.form.get('admin_notes')
        
        if action == 'approve':
            # Ödemeyi onayla ve bakiye ekle
            payment.status = 'completed'
            payment.admin_notes = admin_notes
            
            # Kullanıcıya bakiye ekle
            payment.user.balance += payment.amount
            
            db.session.commit()
            
            # Kullanıcıya bildirim gönder (destek talebi yanıtı)
            ticket = SupportTicket.query.filter_by(user_id=payment.user_id).order_by(SupportTicket.created_at.desc()).first()
            
            if ticket:
                # Admin kullanıcısını bul
                admin_user = User.query.filter_by(is_admin=True).first()
                
                admin_reply = TicketReply(
                    content=f"""Ödemeniz onaylandı ve {payment.amount} ₺ bakiyeniz hesabınıza tanımlandı.
                    
                    Teşekkür ederiz.""",
                    ticket_id=ticket.id,
                    user_id=admin_user.id,
                    is_from_admin=True,
                    is_internal_note=False
                )
                
                db.session.add(admin_reply)
                db.session.commit()
            
            flash('Ödeme başarıyla onaylandı ve kullanıcıya bakiye eklendi.', 'success')
        
        elif action == 'reject':
            # Ödemeyi reddet
            payment.status = 'failed'
            payment.admin_notes = admin_notes
            db.session.commit()
            
            # Kullanıcıya bildirim gönder (destek talebi yanıtı)
            ticket = SupportTicket.query.filter_by(user_id=payment.user_id).order_by(SupportTicket.created_at.desc()).first()
            
            if ticket:
                # Admin kullanıcısını bul
                admin_user = User.query.filter_by(is_admin=True).first()
                
                admin_reply = TicketReply(
                    content=f"""Ödemeniz reddedildi.
                    
                    Sebep: {admin_notes}
                    
                    Lütfen ödeme bilgilerinizi kontrol edip tekrar deneyiniz veya destek ekibimizle iletişime geçiniz.""",
                    ticket_id=ticket.id,
                    user_id=admin_user.id,
                    is_from_admin=True,
                    is_internal_note=False
                )
                
                db.session.add(admin_reply)
                db.session.commit()
            
            flash('Ödeme reddedildi ve kullanıcıya bildirim gönderildi.', 'success')
        
        return redirect(url_for('admin_payments'))
    
    return render_template('admin/view_payment.html', payment=payment)

# Kullanıcının ödeme geçmişini görüntüleme
@app.route('/payment-history')
@login_required
def payment_history():
    # Kullanıcının ödemelerini getir
    payments = Payment.query.filter_by(user_id=current_user.id).order_by(Payment.created_at.desc()).all()
    return render_template('user/payment_history.html', payments=payments)

# Admin routes
@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    total_users = User.query.count()
    total_accounts = GameAccount.query.count()
    total_orders = Order.query.count()
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(5).all()
    
    return render_template('admin/dashboard.html', 
                          total_users=total_users,
                          total_accounts=total_accounts,
                          total_orders=total_orders,
                          recent_orders=recent_orders)

@app.route('/admin/users')
@login_required
@admin_required
def admin_users():
    users = User.query.all()
    return render_template('admin/users.html', users=users)

@app.route('/admin/user/<int:user_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_edit_user(user_id):
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        user.username = request.form.get('username')
        user.email = request.form.get('email')
        user.balance = float(request.form.get('balance', 0))
        
        new_password = request.form.get('new_password')
        if new_password:
            user.set_password(new_password)
        
        db.session.commit()
        flash('Kullanıcı bilgileri güncellendi.', 'success')
        return redirect(url_for('admin_users'))
    
    return render_template('admin/edit_user.html', user=user)

@app.route('/admin/user/delete/<int:user_id>', methods=['POST'])
@login_required
@admin_required
def admin_delete_user(user_id):
    user = User.query.get_or_404(user_id)
    
    if user.is_admin:
        flash('Admin kullanıcısı silinemez.', 'danger')
        return redirect(url_for('admin_users'))
    
    db.session.delete(user)
    db.session.commit()
    
    flash('Kullanıcı silindi.', 'success')
    return redirect(url_for('admin_users'))

@app.route('/admin/tickets')
@login_required
@admin_required
def admin_tickets():
    # URL'den user_id parametresini al
    user_id = request.args.get('user_id', type=int)
    
    # Sorguyu oluştur
    query = SupportTicket.query.order_by(SupportTicket.updated_at.desc())
    
    # Eğer user_id parametresi varsa, sadece o kullanıcının destek taleplerini göster
    if user_id:
        query = query.filter_by(user_id=user_id)
        user = User.query.get_or_404(user_id)
        return render_template('admin/tickets.html', tickets=query.all(), filtered_user=user)
    
    # Tüm destek taleplerini göster
    return render_template('admin/tickets.html', tickets=query.all())

@app.route('/admin/ticket/<int:ticket_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_view_ticket(ticket_id):
    ticket = SupportTicket.query.get_or_404(ticket_id)
    
    if request.method == 'POST':
        content = request.form.get('content')
        is_internal_note = 'is_internal_note' in request.form
        action = request.form.get('action')
        
        if action == 'reply' and content:
            # Yanıt ekle
            reply = TicketReply(
                content=content,
                ticket_id=ticket.id,
                user_id=current_user.id,
                is_from_admin=True,
                is_internal_note=is_internal_note
            )
            
            db.session.add(reply)
            
            # Ticket durumunu güncelle
            if not is_internal_note:  # İç not değilse durumu güncelle
                ticket.status = 'in_progress'
            
            ticket.updated_at = datetime.utcnow()
            db.session.commit()
            
            flash('Yanıtınız gönderildi.', 'success')
        elif action == 'change_status':
            new_status = request.form.get('status')
            if new_status in ['open', 'in_progress', 'closed', 'resolved']:
                ticket.status = new_status
                if new_status in ['closed', 'resolved']:
                    ticket.closed_at = datetime.utcnow()
                ticket.updated_at = datetime.utcnow()
                db.session.commit()
                flash(f'Destek talebi durumu "{new_status}" olarak güncellendi.', 'success')
        elif action == 'change_priority':
            new_priority = request.form.get('priority')
            if new_priority in ['low', 'normal', 'high', 'urgent']:
                ticket.priority = new_priority
                ticket.updated_at = datetime.utcnow()
                db.session.commit()
                flash(f'Destek talebi önceliği "{new_priority}" olarak güncellendi.', 'success')
        elif action == 'toggle_lock':
            ticket.is_locked = not ticket.is_locked
            ticket.updated_at = datetime.utcnow()
            db.session.commit()
            status = 'kilitlendi' if ticket.is_locked else 'kilidi açıldı'
            flash(f'Destek talebi {status}.', 'success')
        
        return redirect(url_for('admin_view_ticket', ticket_id=ticket.id))
    
    return render_template('admin/view_ticket.html', ticket=ticket)

@app.route('/admin/categories')
@login_required
@admin_required
def admin_categories():
    categories = Category.query.all()
    return render_template('admin/categories.html', categories=categories)

@app.route('/admin/category/add', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_add_category():
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        
        if not name:
            flash('Kategori adı gereklidir.', 'danger')
            return render_template('admin/add_category.html')
        
        new_category = Category(name=name, description=description)
        db.session.add(new_category)
        db.session.commit()
        
        # Resim yükleme işlemi
        if 'image' in request.files and request.files['image'].filename:
            image_file = request.files['image']
            if image_file and allowed_file(image_file.filename):
                filename = secure_filename(f"category_{new_category.id}_{image_file.filename}")
                upload_folder = os.path.join(app.root_path, 'static', 'img', 'categories')
                
                # Klasör yoksa oluştur
                if not os.path.exists(upload_folder):
                    os.makedirs(upload_folder)
                
                image_path = os.path.join(upload_folder, filename)
                image_file.save(image_path)
                
                # Veritabanında resim yolunu güncelle
                new_category.image = f"img/categories/{filename}"
                db.session.commit()
        
        flash('Kategori başarıyla eklendi.', 'success')
        return redirect(url_for('admin_categories'))
    
    return render_template('admin/add_category.html')

@app.route('/admin/category/edit/<int:category_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_edit_category(category_id):
    category = Category.query.get_or_404(category_id)
    
    if request.method == 'POST':
        category.name = request.form.get('name')
        category.description = request.form.get('description')
        
        # Resim yükleme işlemi
        if 'image' in request.files and request.files['image'].filename:
            image_file = request.files['image']
            if image_file and allowed_file(image_file.filename):
                # Eski resmi sil (varsa)
                if category.image:
                    old_image_path = os.path.join(app.root_path, 'static', category.image)
                    if os.path.exists(old_image_path):
                        os.remove(old_image_path)
                
                filename = secure_filename(f"category_{category.id}_{image_file.filename}")
                upload_folder = os.path.join(app.root_path, 'static', 'img', 'categories')
                
                # Klasör yoksa oluştur
                if not os.path.exists(upload_folder):
                    os.makedirs(upload_folder)
                
                image_path = os.path.join(upload_folder, filename)
                image_file.save(image_path)
                
                # Veritabanında resim yolunu güncelle
                category.image = f"img/categories/{filename}"
        
        # Resmi kaldır seçeneği işaretlendiyse
        if 'remove_image' in request.form and request.form.get('remove_image') == '1':
            if category.image:
                old_image_path = os.path.join(app.root_path, 'static', category.image)
                if os.path.exists(old_image_path):
                    os.remove(old_image_path)
                category.image = None
        
        db.session.commit()
        flash('Kategori başarıyla güncellendi.', 'success')
        return redirect(url_for('admin_categories'))
    
    return render_template('admin/edit_category.html', category=category)

@app.route('/admin/category/delete/<int:category_id>', methods=['POST'])
@login_required
@admin_required
def admin_delete_category(category_id):
    category = Category.query.get_or_404(category_id)
    
    # Check if category has accounts
    if GameAccount.query.filter_by(category_id=category_id).first():
        flash('Bu kategoride hesaplar bulunduğu için silinemez.', 'danger')
        return redirect(url_for('admin_categories'))
    
    db.session.delete(category)
    db.session.commit()
    
    flash('Kategori silindi.', 'success')
    return redirect(url_for('admin_categories'))

@app.route('/admin/accounts')
@login_required
@admin_required
def admin_accounts():
    accounts = GameAccount.query.all()
    return render_template('admin/accounts.html', accounts=accounts)

@app.route('/admin/account/add', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_add_account():
    categories = Category.query.all()
    
    # GET isteği için şablonu döndür
    if request.method == 'GET':
        return render_template('admin/add_account.html', categories=categories)
    
    if request.method == 'POST':
        title = request.form.get('title')
        category_id = request.form.get('category_id')
        price = float(request.form.get('price', 0))
        description = request.form.get('description')
        is_visible = 'is_visible' in request.form
        
        # Toplu hesap ekleme veya tek hesap kontrolü
        bulk_accounts = request.form.get('bulk_accounts')
        username = request.form.get('username')
        password = request.form.get('password')
        
        if bulk_accounts:
            # Toplu hesap ekleme işlemi
            lines = bulk_accounts.strip().split('\n')
            valid_accounts = []
            
            # Tüm hesapları doğrula
            for line in lines:
                if ':' in line:
                    parts = line.strip().split(':', 1)
                    if len(parts) == 2:
                        acc_username = parts[0].strip()
                        acc_password = parts[1].strip()
                        if acc_username and acc_password:
                            valid_accounts.append((acc_username, acc_password))
            
            if not valid_accounts:
                flash('Geçerli hesap bulunamadı. Lütfen doğru formatta girin (kullanıcıadı:parola).', 'danger')
                return render_template('admin/add_account.html', categories=categories)
            
            # Yeni hesap oluştur
            new_account = GameAccount(
                title=title,
                category_id=category_id,
                price=price,
                description=description,
                stock=len(valid_accounts),  # Stok sayısı = geçerli hesap sayısı
                is_visible=is_visible
            )
            
            # İlk hesabın bilgilerini ana hesap olarak kaydet
            first_account = valid_accounts[0]
            new_account.set_credentials(first_account[0], first_account[1])
            
            # Eğer birden fazla hesap varsa, ek hesapları stok olarak sakla
            if len(valid_accounts) > 1:
                additional_accounts = []
                for i in range(1, len(valid_accounts)):
                    acc = valid_accounts[i]
                    additional_accounts.append({"username": acc[0], "password": acc[1]})
                
                # Ek hesapları JSON olarak sakla
                new_account.additional_stock = json.dumps(additional_accounts)
            
            db.session.add(new_account)
            db.session.flush()  # Hesap ID'sini al
            
            # Görsel yüklemelerini işle
            if 'images' in request.files:
                images = request.files.getlist('images')
                
                for i, image in enumerate(images):
                    if image and image.filename:
                        filename = secure_filename(f"{new_account.id}_{uuid.uuid4().hex[:8]}_{image.filename}")
                        image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                        image.save(image_path)
                        
                        new_image = GameAccountImage(
                            filename=filename,
                            game_account_id=new_account.id,
                            is_primary=(i == 0)  # İlk görsel birincil
                        )
                        
                        db.session.add(new_image)
            
            db.session.commit()
            flash(f'{len(valid_accounts)} hesap başarıyla eklendi.', 'success')
            return redirect(url_for('admin_accounts'))
            
        elif username and password:
            # Tek hesap ekleme işlemi
            new_account = GameAccount(
                title=title,
                category_id=category_id,
                price=price,
                description=description,
                stock=1,
                is_visible=is_visible
            )
            new_account.set_credentials(username, password)
            
            db.session.add(new_account)
            db.session.flush()  # Hesap ID'sini al
            
            # Görsel yüklemelerini işle
            if 'images' in request.files:
                images = request.files.getlist('images')
                
                for i, image in enumerate(images):
                    if image and image.filename:
                        filename = secure_filename(f"{new_account.id}_{uuid.uuid4().hex[:8]}_{image.filename}")
                        image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                        image.save(image_path)
                        
                        new_image = GameAccountImage(
                            filename=filename,
                            game_account_id=new_account.id,
                            is_primary=(i == 0)  # İlk görsel birincil
                        )
                        
                        db.session.add(new_image)
            
            db.session.commit()
            flash('Hesap başarıyla eklendi.', 'success')
            return redirect(url_for('admin_accounts'))
        else:
            flash('Hesap bilgilerini girmelisiniz.', 'danger')
            return render_template('admin/add_account.html', categories=categories)

@app.route('/admin/account/edit/<int:account_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_edit_account(account_id):
    account = GameAccount.query.get_or_404(account_id)
    categories = Category.query.all()
    
    if request.method == 'POST':
        account.title = request.form.get('title')
        account.category_id = request.form.get('category_id')
        account.price = float(request.form.get('price', 0))
        account.description = request.form.get('description')
        account.is_visible = 'is_visible' in request.form
        
        # Ana hesap bilgilerini güncelle
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username and password:
            account.set_credentials(username, password)
        
        # Stok hesaplarını işle
        stock_usernames = request.form.getlist('stock_username[]')
        stock_passwords = request.form.getlist('stock_password[]')
        
        # Geçerli stok hesaplarını oluştur
        additional_accounts = []
        for i in range(len(stock_usernames)):
            if stock_usernames[i] and stock_passwords[i]:
                additional_accounts.append({
                    "username": stock_usernames[i],
                    "password": stock_passwords[i]
                })
        
        # Stok sayısını güncelle (ana hesap + ek hesaplar)
        account.stock = 1 + len(additional_accounts)
        
        # Ek hesapları JSON olarak sakla
        if additional_accounts:
            account.additional_stock = json.dumps(additional_accounts)
        else:
            account.additional_stock = None
        
        # Görsel yüklemelerini işle
        if 'images' in request.files:
            images = request.files.getlist('images')
            
            for i, image in enumerate(images):
                if image and image.filename:
                    filename = secure_filename(f"{account.id}_{uuid.uuid4().hex[:8]}_{image.filename}")
                    image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    image.save(image_path)
                    
                    # Eğer birincil görsel yoksa, bunu birincil yap
                    is_primary = not GameAccountImage.query.filter_by(game_account_id=account.id, is_primary=True).first()
                    
                    new_image = GameAccountImage(
                        filename=filename,
                        game_account_id=account.id,
                        is_primary=is_primary
                    )
                    
                    db.session.add(new_image)
        
        db.session.commit()
        flash('Hesap başarıyla güncellendi.', 'success')
        return redirect(url_for('admin_accounts'))
    
    # Mevcut hesap bilgilerini al
    credentials = account.get_credentials()
    
    # Ek stok hesaplarını al
    additional_accounts = []
    if account.additional_stock:
        try:
            additional_accounts = json.loads(account.additional_stock)
        except:
            pass
    
    return render_template('admin/edit_account.html', 
                          account=account, 
                          categories=categories,
                          credentials=credentials,
                          additional_accounts=additional_accounts)

@app.route('/admin/account/delete/<int:account_id>', methods=['POST'])
@login_required
@admin_required
def admin_delete_account(account_id):
    account = GameAccount.query.get_or_404(account_id)
    
    # Delete associated images from filesystem
    for image in account.images:
        try:
            os.remove(os.path.join(app.config['UPLOAD_FOLDER'], image.filename))
        except:
            pass
    
    db.session.delete(account)
    db.session.commit()
    
    flash('Hesap silindi.', 'success')
    return redirect(url_for('admin_accounts'))

@app.route('/admin/account/image/delete/<int:image_id>', methods=['POST'])
@login_required
@admin_required
def admin_delete_account_image(image_id):
    image = GameAccountImage.query.get_or_404(image_id)
    account_id = image.game_account_id
    
    # Delete image file
    try:
        os.remove(os.path.join(app.config['UPLOAD_FOLDER'], image.filename))
    except:
        pass
    
    # If this was the primary image, set another image as primary
    if image.is_primary:
        next_image = GameAccountImage.query.filter_by(game_account_id=account_id).filter(GameAccountImage.id != image_id).first()
        if next_image:
            next_image.is_primary = True
    
    db.session.delete(image)
    db.session.commit()
    
    flash('Resim silindi.', 'success')
    return redirect(url_for('admin_edit_account', account_id=account_id))

@app.route('/admin/account/image/set-primary/<int:image_id>', methods=['POST'])
@login_required
@admin_required
def admin_set_primary_image(image_id):
    image = GameAccountImage.query.get_or_404(image_id)
    account_id = image.game_account_id
    
    # Reset all primary flags for this account
    for img in GameAccountImage.query.filter_by(game_account_id=account_id).all():
        img.is_primary = False
    
    # Set this image as primary
    image.is_primary = True
    db.session.commit()
    
    flash('Ana resim güncellendi.', 'success')
    return redirect(url_for('admin_edit_account', account_id=account_id))

@app.route('/admin/orders')
@login_required
@admin_required
def admin_orders():
    orders = Order.query.order_by(Order.created_at.desc()).all()
    return render_template('admin/orders.html', orders=orders)

@app.route('/admin/order/<int:order_id>')
@login_required
@admin_required
def admin_view_order(order_id):
    order = Order.query.get_or_404(order_id)
    return render_template('admin/view_order.html', order=order)

@app.route('/admin/settings', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_settings():
    # Mevcut ayarları al veya yeni oluştur
    settings = db.session.query(Settings).first()
    if not settings:
        settings = Settings()
        db.session.add(settings)
        db.session.commit()
    
    if request.method == 'POST':
        username = request.form.get('username')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        # Ödeme bilgilerini al
        bank_name = request.form.get('bank_name')
        bank_account_name = request.form.get('bank_account_name')
        bank_iban = request.form.get('bank_iban')
        papara_account_name = request.form.get('papara_account_name')
        papara_number = request.form.get('papara_number')
        payment_instructions = request.form.get('payment_instructions')
        
        if not username:
            flash('Kullanıcı adı gereklidir.', 'danger')
            return render_template('admin/settings.html', settings=settings)
        
        # Admin bilgilerini güncelle
        current_user.username = username
        
        # Şifre güncelleme
        if new_password:
            if new_password != confirm_password:
                flash('Şifreler eşleşmiyor.', 'danger')
                return render_template('admin/settings.html', settings=settings)
            
            current_user.set_password(new_password)
        
        # Ödeme bilgilerini güncelle
        settings.bank_name = bank_name
        settings.bank_account_name = bank_account_name
        settings.bank_iban = bank_iban
        settings.papara_account_name = papara_account_name
        settings.papara_number = papara_number
        settings.payment_instructions = payment_instructions
        
        db.session.commit()
        flash('Ayarlar başarıyla güncellendi.', 'success')
        return redirect(url_for('admin_dashboard'))
    
    return render_template('admin/settings.html', settings=settings)

# Helper functions
def allowed_file(filename):
    # İzin verilen dosya uzantıları
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Create admin user if not exists
# Initialize database and create admin user
def create_admin():
    with app.app_context():
        db.create_all()
        
        # Check if admin exists
        admin = User.query.filter_by(is_admin=True).first()
        if not admin:
            admin = User(
                username='admin',
                email='admin@example.com',
                is_admin=True
            )
            admin.set_password('admin')
            db.session.add(admin)
            db.session.commit()

# Veritabanını oluştur ve admin kullanıcısını ekle
with app.app_context():
    # Önce veritabanı tablolarını oluştur
    db.create_all()
    
    # Sonra admin kullanıcısını oluştur
    create_admin()
    
    # Settings tablosunu kontrol et ve yoksa oluştur
    settings = Settings.query.first()
    if not settings:
        settings = Settings()
        db.session.add(settings)
        db.session.commit()
        print("Settings tablosu oluşturuldu.")
    
    print("Veritabanı ve tablolar başarıyla oluşturuldu.")

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
