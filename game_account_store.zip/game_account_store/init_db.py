import os
import sys
from datetime import datetime
from werkzeug.security import generate_password_hash
import json
import random

# Add the current directory to the path so we can import our app
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import app, db
from models import User, Category, GameAccount, GameAccountImage, Message

def init_db():
    with app.app_context():
        # Create tables
        db.create_all()
        
        # Check if admin exists
        admin = User.query.filter_by(is_admin=True).first()
        if not admin:
            print("Creating admin user...")
            admin = User(
                username='admin',
                email='admin@example.com',
                is_admin=True
            )
            admin.set_password('admin')
            db.session.add(admin)
        
        # Create test user if not exists
        test_user = User.query.filter_by(username='test').first()
        if not test_user:
            print("Creating test user...")
            test_user = User(
                username='test',
                email='test@example.com',
                balance=100.0
            )
            test_user.set_password('test123')
            db.session.add(test_user)
        
        # Create categories if not exists
        categories = [
            {"name": "Steam", "description": "Steam platformu için oyun hesapları"},
            {"name": "Epic Games", "description": "Epic Games platformu için oyun hesapları"},
            {"name": "Origin", "description": "Origin platformu için oyun hesapları"},
            {"name": "Uplay", "description": "Ubisoft Connect platformu için oyun hesapları"},
            {"name": "Battle.net", "description": "Battle.net platformu için oyun hesapları"},
            {"name": "Windows", "description": "Windows işletim sistemi lisans anahtarları"}
        ]
        
        existing_categories = {c.name: c for c in Category.query.all()}
        
        for cat_data in categories:
            if cat_data["name"] not in existing_categories:
                print(f"Creating category: {cat_data['name']}")
                category = Category(name=cat_data["name"], description=cat_data["description"])
                db.session.add(category)
                db.session.flush()  # Get the ID
            else:
                print(f"Category {cat_data['name']} already exists")
        
        # Commit to get category IDs
        db.session.commit()
        
        # Get all categories
        all_categories = Category.query.all()
        
        # Sample accounts data
        accounts = [
            {
                "title": "Steam Hesabı - 50+ Oyun Kütüphanesi",
                "description": "50'den fazla popüler oyun içeren premium Steam hesabı. GTA V, CS:GO, PUBG ve daha fazlası!",
                "price": 299.99,
                "stock": 3,
                "credentials": {"username": "steam_user123", "password": "securepass123"},
                "category_name": "Steam"
            },
            {
                "title": "Epic Games - Fortnite Nadir Skinler",
                "description": "Nadir skinler ve kozmetikler içeren Fortnite hesabı. Season 1'den beri aktif.",
                "price": 199.99,
                "stock": 2,
                "credentials": {"username": "epic_player", "password": "epicpass456"},
                "category_name": "Epic Games"
            },
            {
                "title": "Origin Premium - EA Play Pro",
                "description": "EA Play Pro aboneliği aktif, tüm EA oyunlarına erişim. Battlefield, FIFA, Madden ve daha fazlası!",
                "price": 149.99,
                "stock": 5,
                "credentials": {"username": "origin_gamer", "password": "eaplay789"},
                "category_name": "Origin"
            },
            {
                "title": "Windows 10 Pro Lisans Anahtarı",
                "description": "Orijinal Windows 10 Pro lisans anahtarı. Ömür boyu kullanım garantili.",
                "price": 89.99,
                "stock": 10,
                "credentials": {"username": "N/A", "password": "WXYZ-ABCD-EFGH-IJKL-MNOP"},
                "category_name": "Windows"
            },
            {
                "title": "Battle.net - World of Warcraft Hesabı",
                "description": "Tüm genişletme paketlerine sahip, yüksek seviyeli karakterler içeren WoW hesabı.",
                "price": 249.99,
                "stock": 1,
                "credentials": {"username": "wow_player", "password": "wowpass123"},
                "category_name": "Battle.net"
            },
            {
                "title": "Uplay - Assassin's Creed Koleksiyonu",
                "description": "Tüm Assassin's Creed oyunlarını içeren premium Uplay hesabı.",
                "price": 179.99,
                "stock": 3,
                "credentials": {"username": "assassin_fan", "password": "ubisoft456"},
                "category_name": "Uplay"
            }
        ]
        
        # Create accounts if not exists
        existing_accounts = {a.title: a for a in GameAccount.query.all()}
        
        for acc_data in accounts:
            if acc_data["title"] not in existing_accounts:
                # Find category
                category = next((c for c in all_categories if c.name == acc_data["category_name"]), None)
                
                if category:
                    print(f"Creating account: {acc_data['title']}")
                    account = GameAccount(
                        title=acc_data["title"],
                        description=acc_data["description"],
                        price=acc_data["price"],
                        stock=acc_data["stock"],
                        category_id=category.id,
                        is_visible=True,
                        credentials=json.dumps(acc_data["credentials"])
                    )
                    db.session.add(account)
                    db.session.flush()  # Get the ID
                    
                    # Create a dummy image for the account
                    image = GameAccountImage(
                        filename=f"dummy_{random.randint(1, 1000)}.jpg",
                        is_primary=True,
                        game_account_id=account.id
                    )
                    db.session.add(image)
            else:
                print(f"Account {acc_data['title']} already exists")
        
        # Create welcome message for test user
        if test_user and not Message.query.filter_by(user_id=test_user.id).first():
            print("Creating welcome message for test user...")
            welcome_message = Message(
                subject="Hoş Geldiniz!",
                content="Oyun Hesabı Satış Platformu'na hoş geldiniz! Herhangi bir sorunuz olursa bizimle iletişime geçebilirsiniz.",
                user_id=test_user.id,
                created_at=datetime.utcnow()
            )
            db.session.add(welcome_message)
        
        # Commit all changes
        db.session.commit()
        print("Database initialized successfully!")

if __name__ == "__main__":
    init_db()
