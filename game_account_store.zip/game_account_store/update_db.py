import sqlite3
import os

# Veritabanı dosyasının yolu
db_path = os.path.join(os.path.dirname(__file__), 'game_store.db')

# Veritabanına bağlan
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Veritabanı şemasını güncelle
try:
    # categories tablosuna image sütunu ekle
    cursor.execute('ALTER TABLE categories ADD COLUMN image TEXT')
    print("categories tablosuna image sütunu eklendi.")
except sqlite3.OperationalError as e:
    if "duplicate column name" in str(e):
        print("image sütunu zaten mevcut.")
    else:
        print(f"Hata: {e}")

# Settings tablosunu oluştur (eğer yoksa)
cursor.execute('''
CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    shopier_api_key TEXT,
    shopier_api_secret TEXT,
    shopier_callback_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
''')
print("settings tablosu oluşturuldu veya güncellendi.")

# Değişiklikleri kaydet ve bağlantıyı kapat
conn.commit()
conn.close()

print("Veritabanı güncelleme işlemi tamamlandı.")
