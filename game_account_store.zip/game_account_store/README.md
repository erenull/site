# Oyun Hesabı Satış Platformu

Bu proje, Flask kullanılarak geliştirilmiş tam özellikli bir oyun hesabı satış platformudur.

## Özellikler

- Kullanıcı kaydı, giriş ve çıkış işlemleri
- Admin paneli
- Oyun hesaplarının kategorilere göre listelenmesi
- Kullanıcı paneli ve hesap yönetimi
- Shopier ödeme entegrasyonu
- Responsive modern arayüz

## Kurulum

1. Gerekli paketleri yükleyin:
   ```
   pip install -r requirements.txt
   ```

2. Uygulamayı başlatın:
   ```
   python app.py
   ```

3. Tarayıcınızda `http://localhost:5000` adresine gidin.

## Admin Girişi

Varsayılan admin bilgileri:
- Kullanıcı adı: admin
- Şifre: admin

## Lisans

Bu proje MIT lisansı altında lisanslanmıştır.
